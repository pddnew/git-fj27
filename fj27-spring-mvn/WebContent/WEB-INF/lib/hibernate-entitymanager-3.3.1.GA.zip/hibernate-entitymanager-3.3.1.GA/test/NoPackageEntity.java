//$Id: $

/**
 * @author Emmanuel Bernard
 */
public class NoPackageEntity {
	private Integer id;
	private String name;
}
