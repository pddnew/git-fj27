Hibernate Entity Manager dependencies
=====================================


Core
====
hibernate-commons-annotations.jar: required
ejb3-persistence.jar: required
hibernate-annotations: required
hibernate-validator: required
hibernate3.jar: required
hibernate core dependencies: required (see Hibernate Core for more information)
javassist.jar: required (part of Hibernate Core dependencies)
jboss-archive-browsing (jboss-common-core 2.0.2.Alpha): required


Test
====
(no extra dependency)